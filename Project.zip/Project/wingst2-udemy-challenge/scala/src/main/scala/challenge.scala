import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row

object Main extends App {


//*********************************************************************//
// NOTE: Please refer to problem statements from challenge.html file   //
// found under instructions folder for detailed requirements. We have  //
// defined placeholder functions where you need to add your code that  //
// may solve one or more of the the problem statements. Within the     // 
// functions we have added DEFAULT code which when executed without    //
// any modification would create empty dataframe. This approach will   // 
// enable you to test your code intermediate without worrying about    // 
// syntax failure outside of your code. To SOLVE the problem, you are  //
// expected to REPLACE the code which creates dummy dataframe with     //
// your ACTUAL code.                                                   //
//*********************************************************************//
// NOTE: We have also added code to print sample data to console in    //
// each of the functions to help you visualize your intermediate data  //
//*********************************************************************//



def transformed_data(spark: SparkSession,input_file: String): DataFrame = 
{
  
  println("-------------------------")
  println("Starting transformed_data")
  println("-------------------------")

///_______________________________________________________________________________________________________________
    // 1) Load the CSV file into a dataframe with header as true and inferSchema as true.                             |
    // 2) There are many columns in the data, so fetch only the following columns to move further : -                 |
    //       - course_id, price, num_subscribers, num_reviews, level, content_duration, published_timestamp, subject. |
    // 3) Change the datatype for the fetched columns : -                                                             |
    //       * course_id – int                                                                                        |
    //       * price – int                                                                                            |
    //       * num_subscribers – int                                                                                  |
    //       * num_reviews – int                                                                                      |
    //       * level – string                                                                                         |
    //       * content_duration – float                                                                               |
    //       * published_timestamp – timestamp                                                                        |
    //       * subject - string                                                                                       |
    // 4) Return statement is already defined and you need to replace the df with your final output dataframe name.   |
    //________________________________________________________________________________________________________________|    
   
  //Write your code below this line
  var transformed_data = spark.emptyDataFrame //Replace this line with your actual code
  
  return transformed_data //make sure you  return the final transformed dataframe.
  //Write your code above this line

}


def price_data(input_df: DataFrame): DataFrame = 
{
  /**
    * @param input_df : the output of transformed_data given as input to this function  
    * @return a new Dataframe
    */
 
  println("--------------------------")
  println("Starting price_data")
  println("--------------------------")

 //________________________________________________________________________________________________________
    // 1) Get the sum of the price based on level and subject columns. Change the column name to Total_price.|
    //        - Columns to be fetched: - level, subject, Total_price.                                        |
    // 2) Order the level column in asending and Total_price column in descending.                           |
    // 3) Return statement is already defined and you need to replace the price_df                           |
    //    with your final output dataframe name.                                                             |
    //_______________________________________________________________________________________________________|
//----------------------------------------------------------------------


  //Write your code below this line
  //NOTE - The final dataframe created should contain all transformations stated above.
  var price_data = input_df //Replace this line with your actual code
 

  return price_data //make sure you  return the final transformed dataframe.

}


def sub_data(input_df: DataFrame): DataFrame = 
{
  /** 
    * @param input_df : the output of transformed_data given as input to this function 
    * @return a new Dataframe
    */
  println("-------------------------")
  println("Starting sub_data   ")
  println("-------------------------")
 //__________________________________________________________________________________________________________________
    // 1) Fetch the all records where the level is Expert Level.                                                        |
    // 2) Perform the following operation in a new column. The column name should be sub_level                          |
    //       - If the num_subscribers is greater than 1000, then display “High”                                         |
    //       - If the num_subscribers is greater than 500 and less than or equal to 1000, then display “Medium”         |
    //       - Otherwise display “Low”                                                                                  |
    // 3) Fetch only the following columns: -                                                                           |
    //     - course_id, num_subscribers, level, sub_level                                                               |
    // 4) Return statement is already defined and you need to replace the sub_df with your final output dataframe name. |
    //__________________________________________________________________________________________________________________|
    
   
  //Write your code below this line
  var sub_data = input_df //Replace this line with your actual code
 

  return sub_data //make sure you  return the final transformed dataframe.
  //Write your code above this line

}

def years_data(input_df: DataFrame): DataFrame = 
{
  /**
    * @param input_df: the output of transformed_data given as input to this function
    * @return a new Dataframe
    */
  println("-----------------------")
  println("Starting years_data    ")
  println("-----------------------")

 //___________________________________________________________________________________________________
    // 1) Fetch the following columns : -                                                                |
    //      - course_id, price, level, published_timestamp                                               |
    // 2) Fetch the records which have the price greater than 100 and the published_timestamp between    |
    //    2012-01-01 and 2015-01-01. But 2015-01-01 records should not be included.                      |
    // 3) Order the published_timestamp in ascending, price in decending.                                |
    // 4) Return statement is already defined and you need to replace the years_df with your final       |
    //    output dataframe name.                                                                         |
    //___________________________________________________________________________________________________|



      
  // Write your code below this line
  //NOTE - The final dataframe created should contain all transformations stated above.
  var years_data = input_df //Replace this line with your actual code
 

  return years_data //make sure you  return the final transformed dataframe.
  //Write your code above this line

}

def load_data(data: DataFrame,output_path: String) = 
{
  /**
  
    * @param data : All the tasks output data frame.
    * @param outputpath: Location where the file needs to be saved
  */
//------------------------------------------------------------------------|
// 1. Write a code to store the outputs to the respective locations.      |
// Note:                                                                  |
//       • Output files should be a single partition CSV file with header.|
//       • load_data function is important for all the tasks.             |
//-------------------------------------------------------------------------

    if (!data.isEmpty)
    {
      println("Starting load_data :",output_path)

      //Write your code below this line
      
      //Write your code above this line
    }
    else {
      println("Empty dataframe, hence cannot save the data") 
    }
}





def main(){
  /**Main driver program to control the flow of execution.
     NOTE: Please DO NOT change anything here as it will impact execution of the program.
  */			  

  //Clean the output files for fresh execution
  outputfile_cleanup()

  //Get a new spark session
  val spark = get_spark_session()
  
  //Set up the files path and names
  val input_file = os.pwd/os.up/'inputfile + "/udemy_courses.csv"
  val output_path = os.pwd/os.up/'output
  val result_1_path = output_path + "/price_data"
  val result_2_path = output_path + "/sub_data"
  val result_3_path = output_path + "/years_data"
  val result_4_path = output_path + "/transformed_data"
  val task1 = transformed_data(spark,input_file)
  val task2 = price_data(task1)
  val task3 = sub_data(task1)
  val task4 = years_data(task1)

  try{
    load_data(task2,result_1_path)
  } catch {

    case e : Exception =>
    println("Getting error while loading price_data " +  e.getMessage)
  }
 
 try{
    load_data(task3,result_2_path)
  } catch {

    case e : Exception =>
    println("Getting error while loading sub_data " +  e.getMessage)
  }

  try{
    load_data(task4,result_3_path)
  } catch {

    case e : Exception =>
    println("Getting error while loading years_data " +  e.getMessage)
  }


  try{
    load_data(task1,result_4_path)
  } catch {

    case e : Exception =>
    println("Getting error while loading transformed_data " +  e.getMessage)
  }
  
  //Stop spark session
  spark.stop()

}
def outputfile_cleanup() =
{
  /** Clean up the output files for a fresh execution.
      This is executed every time a job is run. 
      NOTE: Please DO NOT change anything here as it will impact execution of the program.
  */
  val path = os.pwd/os.up/'output
  println(path)
  if(os.exists(path)){
      println("path exists")
      os.remove.all(path)
      os.makeDir(path)
  }
  else{
    os.makeDir(path)
  }

}
def get_spark_session(): SparkSession = 
{
  /** Create new spark session. Please DO NOT change anything here.
    * @return: New spark session
  */  
  val spark = SparkSession
              .builder
			        .master("local")
              .appName("Udemy data analysis")
              .getOrCreate()
  spark.sparkContext.setLogLevel("ERROR")
  return spark
}
main()
}