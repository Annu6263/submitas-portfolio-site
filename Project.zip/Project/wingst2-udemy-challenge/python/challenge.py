 # -*- coding: utf-8 -*-
import os
import shutil
import pyspark
from pyspark.sql.window import Window
from pyspark.sql import SparkSession
from pyspark.sql.functions import * 
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType, DateType,TimestampType
from pyspark.sql.functions import rank
from pyspark.sql.functions import row_number
from pyspark.sql.functions import dense_rank
#*********************************************************************//
# Note: Please refer to problem statements from problemstatement file //
# found under instructions folder for detailed requirements. We have  //
# defined placeholder functions where you need to add your code that  //
# may solve one or more of the the problem statements. Within the     // 
# functions we have added DEFAULT code which when executed without    //
# any modification would create empty dataframe. This approach will   // 
# enable you to test your code intermediate without worrying about    // 
# syntax failure outside of your code. To SOLVE the problem, you are  //
# expected to REPLACE the code which creates dummy dataframe with     //
# your ACTUAL code.                                                   //
#*********************************************************************//
# Note: We have also added code to print sample data to console in    //
# each of the functions to help you visualize your intermediate data  //
#*********************************************************************//


def transformed_data(spark,input_file):
    ''' 
  spark_session : spark 
  for input_file : input_file 
  '''
  #________________________________________________________________________________________________________________
    # 1) Load the CSV file into a dataframe with header as true and inferSchema as true.                             |
    # 2) There are many columns in the data, so fetch only the following columns to move further : -                 |
    #       - course_id, price, num_subscribers, num_reviews, level, content_duration, published_timestamp, subject. |
    # 3) Change the datatype for the fetched columns : -                                                             |
    #       * course_id – int                                                                                        |
    #       * price – int                                                                                            |
    #       * num_subscribers – int                                                                                  |
    #       * num_reviews – int                                                                                      |
    #       * level – string                                                                                         |
    #       * content_duration – float                                                                               |
    #       * published_timestamp – timestamp                                                                        |
    #       * subject - string                                                                                       |
    # 4) Return statement is already defined and you need to replace the df with your final output dataframe name.   |
    #________________________________________________________________________________________________________________|    
    
    #Write your code below this line

    
    
    df = spark.read.csv(input_file, header=True, inferSchema=True)
     #replace this line with your  actual code
    
    
    
    
    return df  #return the final dataframe




def price_data(input_df):
    '''
    for input file: input_df
    '''
    print("-------------------")
    print("Starting price_data")
    print("-------------------")


 #________________________________________________________________________________________________________
    # 1) Get the sum of the price based on level and subject columns. Change the column name to Total_price.|
    #        - Columns to be fetched: - level, subject, Total_price.                                        |
    # 2) Order the level column in asending and Total_price column in descending.                           |
    # 3) In challenge file the return statement is already defined and you need to replace the dataframe     |
    #    with your final output dataframe name.                                                             |
    #_______________________________________________________________________________________________________|
    
    #Write your code below this line
    df = input_df
   
    
    
    return df  #return the final dataframe


def sub_data(input_df):
    '''
    for input file: input_df
    '''
    print("-------------------------")
    print("Starting sub_data")
    print("-------------------------")

 #__________________________________________________________________________________________________________________
    # 1) Fetch the all records where the level is Expert Level.                                                        |
    # 2) Perform the following operation in a new column. The column name should be sub_level                          |
    #       - If the num_subscribers is greater than 1000, then display “High”                                         |
    #       - If the num_subscribers is greater than 500 and less than or equal to 1000, then display “Medium”         |
    #       - Otherwise display “Low”                                                                                  |
    # 3) Fetch only the following columns: -                                                                           |
    #     - course_id, num_subscribers, level, sub_level                                                               |
    # 4) Return statement is already defined and you need to replace the sub_df with your final output dataframe name. |
    #__________________________________________________________________________________________________________________|

    #Write your code below this line
    df = input_df   
    
   
    return df   #return the final dataframe

def years_data(input_df):
    '''
    for input file: input_df
    '''
    print("-------------------------")
    print("Starting years_data")
    print("-------------------------")


#___________________________________________________________________________________________________
    # 1) Fetch the following columns : -                                                                |
    #      - course_id, price, level, published_timestamp                                               |
    # 2) Fetch the records which have the price greater than 100 and the published_timestamp between    |
    #    2012-01-01 and 2015-01-01. But 2015-01-01 records should not be included.                      |
    # 3) Order the published_timestamp in ascending, price in decending.                                |
    # 4) Return statement is already defined and you need to replace the years_df with your final       |
    #    output dataframe name.                                                                         |
    #___________________________________________________________________________________________________|

    #Write your code below this line
    df = input_df
   

    return df     #return the final dataframe"""  """

""" """  """ """
def load_data(data,output_path):

#------------------------------------------------------------------------
# 1. Write a code to store the outputs to the respective locations. 	|
# Note:									|
# • Output files should be a single partition CSV file with header.	|
# • load_data function is important for all the tasks. 			|
#------------------------------------------------------------------------

    if (data.count() != 0):
        print("Loading the data",output_path)
        df.coalesce(1).write.mode("overwrite").option("header", True).csv(output_path)
       
        #Write your code above this line
    else:
        print("Empty dataframe, hence cannot save the data",output_path)


def main():

    """ Main driver program to control the flow of execution.
        Please DO NOT change anything here.
    """
    #Clean the output files for fresh execution
    outputfile_cleanup()
    #Get a new spark session
    spark = (SparkSession.builder
                         .appName("Udemy data analysis")
                         .master("local")
                         .getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")
    
   
    cwd = os.getcwd()
    dirname = os.path.dirname(cwd)
    input_file = "file://"+ dirname + "/inputfile/udemy_courses.csv"
    output_path = "file://"+ dirname + "/output"
    result_1_path = output_path + "/price_data"
    result_2_path = output_path + "/sub_data"
    result_3_path = output_path + "/years_data"
    result_4_path = output_path + "/transformed_data" 


    try:
        task_1 = transformed_data(spark,input_file)
    except Exception as e:
        print("Getting error in the transformed_data function",e)
    try:
        task_2 = price_data(task_1)
    except Exception as e:
        print("Getting error in the task_2 function",e)
    try:
        task_3 = sub_data(task_1)
    except Exception as e:
        print("Getting error in the task_3 function",e)
    try:
        task_4 = years_data(task_1)      
    except Exception as e:  
        print("Getting error in the task_4 function",e)

    try:
        load_data(task_2,result_1_path)
    except Exception as e:
        print("Getting error while loading price_data",e)

    try:
        load_data(task_3,result_2_path)
    except Exception as e:
        print("Getting error while loading sub_data",e)

    try:
        load_data(task_4,result_3_path)
    except Exception as e:
        print("Getting error while loading years_data",e)

    try:
        load_data(task_1,result_4_path)
    except Exception as e:
        print("Getting error while loading transformed_data",e)

    spark.stop()

def outputfile_cleanup():

    """ Clean up the output files for a fresh execution.
        This is executed every time a job is run. 
        Please DO NOT change anything here.
    """

    cwd = os.getcwd()
    dirname = os.path.dirname(cwd)
    path = dirname + "/output/"
    if (os.path.isdir(path)):
        try:
            shutil.rmtree(path)  
            print("% s removed successfully" % path)
            os.mkdir(path)  
        except OSError as error:  
            print(error)  
    else:
        print("The directory does not exist. Creating..% s", path)
        os.mkdir(path)

if __name__ == "__main__":
	main()
"""  """